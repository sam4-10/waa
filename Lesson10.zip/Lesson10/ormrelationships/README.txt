1. No validations at all. If the inputs have problem, it could cause problem.

2. To view H2 console
enable it: spring.h2.console.enabled=true
access URL: http://localhost:8080/h2-console
Driver Class: org.h2.Driver	
JDBC URL:  jdbc:h2:mem:testdb
User Name: 	sa
no Password